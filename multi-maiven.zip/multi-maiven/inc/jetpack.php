<?php
// Jetpack plugin compatibility
// (Stub for Jetpack compatibility)
